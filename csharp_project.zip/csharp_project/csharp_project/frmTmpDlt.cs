﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace csharp_project
{
    public partial class frmTmpDlt : Form
    {

        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=c:\users\patrick\documents\visual studio 2012\Projects\csharp_project\csharp_project\project1.accdb");
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        readonly DataTable dt = new DataTable();
        BindingSource bSource;

        public frmTmpDlt()
        {
            InitializeComponent();
        }

        private void frmTmpDlt_Load(object sender, EventArgs e)
        {
            btnRetrieve.Enabled = false;

            string sql = "SELECT ID, item, price, stock FROM items WHERE status = 'deleted'";
            cmd = new OleDbCommand(sql, con);
            con.Open();
            adapter = new OleDbDataAdapter(cmd);
            adapter.Fill(dt);
            bSource = new BindingSource();
            bSource.DataSource = dt;

            dataGridView.DataSource = bSource;
            con.Close();

        }

        private void load()
        {

            DataTable dt1 = new DataTable();
            string sql = "SELECT ID, item, price, stock FROM items WHERE status = 'deleted'";
            OleDbCommand cmd1 = new OleDbCommand(sql, con);

            adapter = new OleDbDataAdapter(cmd1);
            adapter.Fill(dt1);
            BindingSource bSource1 = new BindingSource();
            bSource1.DataSource = dt1;

            dataGridView.DataSource = bSource1;



        }

        private void dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            con.Open();

            cmd = new OleDbCommand("UPDATE items SET status = 'active' WHERE ID = @ID", con);
            cmd.Parameters.AddWithValue("@ID", dataGridView.CurrentRow.Cells["ID"].FormattedValue.ToString());
            if(MessageBox.Show("Are you sure you want to retrive this item?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                cmd.ExecuteNonQuery();
                load();
                btnRetrieve.Enabled = false;
            }
            con.Close();
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btnRetrieve.Enabled = true;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

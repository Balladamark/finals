﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace csharp_project
{
    public partial class Items : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=c:\users\patrick\documents\visual studio 2012\Projects\csharp_project\csharp_project\project1.accdb");
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        readonly DataTable dt = new DataTable();
        BindingSource bSource;
        string status = "";


        public Items()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Items_Load(object sender, EventArgs e)
        {
            btnSave.Enabled = false;
            btnCancel.Enabled = false;
            groupBox1.Enabled = false;
            btnTempDel.Enabled = false;
            btnDelete.Enabled = false;
            string sql = "SELECT ID, item, price, stock FROM items WHERE status = 'active'";
            cmd = new OleDbCommand(sql, con);
            con.Open();
            adapter = new OleDbDataAdapter(cmd);
            adapter.Fill(dt);
            bSource = new BindingSource();
            bSource.DataSource = dt;

            dataGridView.DataSource = bSource;
            con.Close();

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;
            txtItemID.Enabled = false;
            btnDelete.Enabled = false;
            btnTempDel.Enabled = false;
            btnEdit.Enabled = false;
            btnSave.Enabled = true;
            btnCancel.Enabled = true;
            txtItemName.Clear();
            txtItemID.Clear();
            txtPrice.Clear();
            txtStock.Clear();
            status = "add";

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            con.Open();

            switch(status){
                case "add":

                    cmd = new OleDbCommand("INSERT INTO items(item, price, stock, status) VALUES(@item, @price, @stock, 'active')", con);
                    cmd.Parameters.AddWithValue("@item",txtItemName.Text);
                    cmd.Parameters.AddWithValue("@price",txtPrice.Text);
                    cmd.Parameters.AddWithValue("@stock", txtStock.Text);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Item successfully added.");
                    }
                    else {
                        MessageBox.Show("Something went wrong!");
                    }

                    break;
                case "edit":
                    cmd = new OleDbCommand("UPDATE items SET item = @item, price = @price, stock = @stock WHERE ID = @id", con);
                    cmd.Parameters.AddWithValue("@item",txtItemName.Text);
                    cmd.Parameters.AddWithValue("@price",txtPrice.Text);
                    cmd.Parameters.AddWithValue("@stock", txtStock.Text);
                    cmd.Parameters.AddWithValue("@ID", txtItemID.Text);
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Item successfully updated.");
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong!");
                    }
                    break;

            }

            

            con.Close();

            load();
            btnDelete.Enabled = true;
            groupBox1.Enabled = false;
            btnEdit.Enabled = true;
            btnAdd.Enabled = true;
            btnDelete.Enabled = false;
            btnTempDel.Enabled = false;
            btnCancel.Enabled = false;

        }
        private void load()
        {

            DataTable dt1 = new DataTable();
            string sql = "SELECT ID, item, price, stock FROM items WHERE status = 'active'";
            OleDbCommand cmd1 = new OleDbCommand(sql, con);

            adapter = new OleDbDataAdapter(cmd1);
            adapter.Fill(dt1);
            BindingSource bSource1 = new BindingSource();
            bSource1.DataSource = dt1;

            dataGridView.DataSource = bSource1;



        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            txtItemID.Text = dataGridView.CurrentRow.Cells["ID"].FormattedValue.ToString();
            txtItemName.Text = dataGridView.CurrentRow.Cells["item"].FormattedValue.ToString();
            txtPrice.Text = dataGridView.CurrentRow.Cells["price"].FormattedValue.ToString();
            txtStock.Text = dataGridView.CurrentRow.Cells["stock"].FormattedValue.ToString();
            status = "edit";
            btnDelete.Enabled = false;
            btnSave.Enabled = true;
            groupBox1.Enabled = true;
            btnTempDel.Enabled = false;
            btnAdd.Enabled = false;
            btnCancel.Enabled = true;
        }

        private void btnTempDel_Click(object sender, EventArgs e)
        {
            con.Open();

            cmd = new OleDbCommand("UPDATE items SET status = 'deleted' WHERE ID = @ID", con);
            cmd.Parameters.AddWithValue("@ID", txtItemID.Text);
            if (MessageBox.Show("Are you sure you want to temporary delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                cmd.ExecuteNonQuery();
                load();
                btnSave.Enabled = false;
                groupBox1.Enabled = false;
                txtItemName.Clear();
                txtItemID.Clear();
                txtPrice.Clear();
                txtStock.Clear();
                btnAdd.Enabled = true;
            }


            con.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();

            cmd = new OleDbCommand("DELETE FROM items WHERE ID = @ID", con);
            cmd.Parameters.AddWithValue("@ID", txtItemID.Text);
            if(MessageBox.Show("Are you sure you want to delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes){

                cmd.ExecuteNonQuery();
                load();
                btnSave.Enabled = false;
                groupBox1.Enabled = false;
                txtItemName.Clear();
                txtItemID.Clear();
                txtPrice.Clear();
                txtStock.Clear();
                btnAdd.Enabled = true;
            }


            con.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            btnSave.Enabled = false;
            groupBox1.Enabled = false;
            txtItemName.Clear();
            txtItemID.Clear();
            txtPrice.Clear();
            txtStock.Clear();
            btnAdd.Enabled = true;

        }

        private void dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void btnViewTemp_Click(object sender, EventArgs e)
        {
            frmTmpDlt tmpdlt = new frmTmpDlt();
            tmpdlt.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frm1 = new Form1();
            frm1.Show();
        }

        private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("hello");
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtItemID.Text = dataGridView.CurrentRow.Cells["ID"].FormattedValue.ToString();
            txtItemName.Text = dataGridView.CurrentRow.Cells["item"].FormattedValue.ToString();
            txtPrice.Text = dataGridView.CurrentRow.Cells["price"].FormattedValue.ToString();
            txtStock.Text = dataGridView.CurrentRow.Cells["stock"].FormattedValue.ToString();

            btnDelete.Enabled = true;
            btnSave.Enabled = false;
            groupBox1.Enabled = false;
            btnTempDel.Enabled = true;
            btnAdd.Enabled = false;
            btnCancel.Enabled = true;

        }

    }
}

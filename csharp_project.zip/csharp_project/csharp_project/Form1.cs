﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace csharp_project
{
    public partial class Form1 : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=c:\users\patrick\documents\visual studio 2012\Projects\csharp_project\csharp_project\project1.accdb");
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string cmdText = "select Count(*) from users where username=? and [password]=?";
    
            OleDbCommand cmd = new OleDbCommand(cmdText, con);
            
            con.Open();
            cmd.Parameters.AddWithValue("@p1", txtUsername.Text);
            cmd.Parameters.AddWithValue("@p2", txtPassword.Text);  // <- is this a variable or a textbox?
            int result = (int)cmd.ExecuteScalar();
            if (result > 0)
            {
                MessageBox.Show("Login Successful");
                txtUsername.Text = "";
                txtPassword.Text = "";
                Items item = new Items();
                item.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Credentials, Please Re-Enter");
            }
            con.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
